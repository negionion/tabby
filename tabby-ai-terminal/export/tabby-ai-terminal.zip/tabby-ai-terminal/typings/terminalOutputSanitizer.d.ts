/**
 * Removes terminal control sequences while keeping ordinary text intact.
 *
 * The parser keeps its state between writes because a terminal can split an
 * ANSI sequence across any number of output chunks.
 */
export declare class TerminalOutputSanitizer {
    private state;
    write(input: string): string;
    private isControlStringIntroducer;
}
export declare function stripTerminalControlSequences(input: string): string;
