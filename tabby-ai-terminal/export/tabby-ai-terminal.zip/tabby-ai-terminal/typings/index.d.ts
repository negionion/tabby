export default class AITerminalModule {
}
